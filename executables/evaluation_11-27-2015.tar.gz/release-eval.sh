#########################################################################
# File Name: release-eval.sh
# Author: Yibo Lin
# mail: yibolin@utexas.edu
# Created Time: Fri 27 Nov 2015 11:31:06 AM CST
#########################################################################
#!/bin/bash

# -out denotes the output of fill insertion results, not the output of evaluation script

./evaluate \
    -in "bench/s.gds" \
    -out "s-out.gds" \
    -route "bench/sM1.txt" \
    -route "bench/sM2.txt" \
    -route "bench/sM3.txt" \
    -score scores/score_s.txt \
    -spacing 32 \
    -width 32 \
    -area 4800 \
    -log "s.log" 
